@echo off
setlocal
cd /d "%~dp0"
echo Arena Kahramanlari APK derlemesi baslatiliyor...
echo Ilk seferde Gradle indirmesi ve Android SDK 36 kurulu olmalidir.
call gradlew.bat assembleDebug
if errorlevel 1 (
  echo.
  echo DERLEME BASARISIZ. Android Studio > SDK Manager bolumunden SDK 36 ve Build-Tools 36.0.0 kurulu oldugunu kontrol et.
  pause
  exit /b 1
)
echo.
echo APK hazir: app\build\outputs\apk\debug\app-debug.apk
pause
