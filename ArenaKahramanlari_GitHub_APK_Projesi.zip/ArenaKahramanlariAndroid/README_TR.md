# Arena Kahramanları — GitHub Actions ile Android APK

Bu depo, HTML oyunun Android uygulaması içine gömülü sürümünü içerir. Oyun dosyası uygulamanın içindedir; kurulumdan sonra internet bağlantısı gerekmez. Uygulama yatay ekran modunda açılır.

## GitHub'dan APK üretme (Android Studio gerektirmez)

1. GitHub'da yeni bir depo oluştur: https://github.com/new
   - Depo adı: `Arena-Kahramanlari`
   - Özel tutmak istersen **Private** seçeneğini işaretle.
2. Bu ZIP'i bilgisayarına indirip çıkar.
3. Çıkardığın `ArenaKahramanlariAndroid` klasörünün **içindeki tüm dosya ve klasörleri** GitHub deposunun köküne yükle. `.github/workflows/build-apk.yml` dosyasının depoda tam olarak bu konumda olmasına dikkat et. ZIP dosyasının kendisini tek başına depoya yüklemek yeterli değildir.
4. Dosyaları `Commit changes` ile kaydet. `main` veya `master` dalına yapılan yükleme otomatik APK derlemesini başlatır.
5. GitHub deposunda **Actions** sekmesini aç ve `Arena Kahramanlari APK olustur` iş akışının tamamlanmasını bekle.
6. Başarılı iş akışı çalışmasını aç. Sayfanın altındaki **Artifacts** bölümünden `Arena-Kahramanlari-APK` dosyasını indir.
7. İndirilen arşivi aç. İçindeki `app-debug.apk` dosyasını Android telefonuna aktar, telefonda aç ve Yükle'ye bas. Gerekirse yalnızca kullandığın dosya yöneticisi/tarayıcı için "Bilinmeyen uygulamaları yükle" iznini etkinleştir.

### Otomatik derlemeyi elle başlatma

GitHub'da **Actions** → `Arena Kahramanlari APK olustur` → **Run workflow** → tekrar **Run workflow**.

## Derleme bilgileri

- Android Gradle Plugin: 9.4.0
- Gradle: 9.6.0
- JDK: 17
- Android SDK hedefi: API 36
- Çıktı: `app/build/outputs/apk/debug/app-debug.apk`
- GitHub Actions artifact saklama süresi: 14 gün

## Notlar

- Bu, telefona kurulabilir debug/test APK'sıdır; Google Play yayını için ayrıca imzalı release/AAB paketi gerekir.
- Bu pakete reklam SDK'sı eklenmemiştir. Oyun mevcut haliyle çevrim dışı botlu sürümdür.
- GitHub Actions derlemesi sırasında internet gerekir; APK içindeki oyun ise çevrim dışı açılır.
