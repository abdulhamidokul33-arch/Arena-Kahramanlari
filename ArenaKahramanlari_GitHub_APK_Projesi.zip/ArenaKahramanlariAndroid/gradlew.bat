@echo off
setlocal
set "APP_HOME=%~dp0"
if not "%JAVA_HOME%"=="" (
  set "JAVA_BIN=%JAVA_HOME%\bin\java.exe"
) else (
  set "JAVA_BIN=java.exe"
)
"%JAVA_BIN%" -Dgradle.wrapper.projectDir="%APP_HOME%" -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
